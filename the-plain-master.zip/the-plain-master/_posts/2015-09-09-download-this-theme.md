---
title: Download this Theme
updated: 2015-09-09 10:38
---

The Plain is a minimalist Jekyll theme, designed to focus on writing that really matters to you and your audience. Everything else is just a distraction. Nothing more other than useful and understandable information sharing. I have made a final update to this theme. This theme is suit best for personal blog type, but not limited to.

**_Fork_** or **_download_** the theme [here on GitHub](https://github.com/heiswayi/the-plain).
